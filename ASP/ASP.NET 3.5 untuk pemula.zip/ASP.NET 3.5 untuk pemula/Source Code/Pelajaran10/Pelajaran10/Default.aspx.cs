﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Modul10
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Application["CounterAplikasi"] = int.Parse(Application["CounterAplikasi"].ToString()) + 1;
            LabelCounterAplikasi.Text = Application["CounterAplikasi"].ToString();
            Session["CounterPengguna"] = int.Parse(Session["CounterPengguna"].ToString()) + 1;
            LabelCounterPengguna.Text = Session["CounterPengguna"].ToString();
        }
    }
}
