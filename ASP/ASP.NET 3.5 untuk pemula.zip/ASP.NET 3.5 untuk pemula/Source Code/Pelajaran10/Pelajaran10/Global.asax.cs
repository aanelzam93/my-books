﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

namespace Modul10
{
    public class Global : System.Web.HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            //saat aplikasi diinisialisasi
            Application["CounterAplikasi"] = 0;
        }

        protected void Session_Start(object sender, EventArgs e)
        {
            //saat session baru dimulai
            Session["CounterPengguna"] = 0;
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            //saat ada request terhadap resource tertentu pada aplikasi
        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {
            //saat melakukan autentikasi untuk sebuah request pada aplikasi
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            //saat ada error yang tidak ditangani dalam aplikasi
        }

        protected void Session_End(object sender, EventArgs e)
        {
            //saat session selesai atau timeout
        }

        protected void Application_End(object sender, EventArgs e)
        {
            //saat aplikasi selesai
        }

    }
}