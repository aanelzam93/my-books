﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        updateLabelDate();
    }

    private void updateLabelDate()
    {
        LabelDate.Text = System.DateTime.Now.ToString();
        LabelShow.Text = "Please put some text on the textbox and press the button";
    }
    protected void ButtonPost_Click(object sender, EventArgs e)
    {
        postToLabelShow();
    }

    private void postToLabelShow()
    {
        LabelShow.Text = Int32.Parse(TextBoxPost.Text + 20);
    }
}
